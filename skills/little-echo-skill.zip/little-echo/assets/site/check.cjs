const fs=require('fs'),vm=require('vm'),assert=require('assert');
const elements=new Map();
const document={querySelector:s=>{if(!elements.has(s))elements.set(s,{innerHTML:'',classList:{toggle(){}},value:''});return elements.get(s)},querySelectorAll:()=>[]};
const ctx={document,sessionStorage:{getItem(){return null},setItem(){},removeItem(){}},window:{scrollTo(){},confirm(){return true}},console,assert};
vm.createContext(ctx);
vm.runInContext(fs.readFileSync('dist/data.js','utf8')+'\n'+fs.readFileSync('dist/app.js','utf8')+`
assert.equal(CHILD_Q.length,5);assert.equal(PARENT_Q.length,5);
assert.equal(profile([0,0,1,2,4]).primary,0);
assert.equal(profile([0,0,1,1,4]).primary,null);
assert.equal(profile([0,0,4,4,4]).primary,null);
assert.equal(profile([4,4,4,4,4]).valid,0);
state.view='age';render();assert.equal(state.view,'follow');assert(root.innerHTML.includes('https://xhslink.cn/o/77WXzU2bT0H'));assert(root.innerHTML.includes('无法读取或核验'));
$('#confirm-follow').onclick();assert.equal(state.view,'follow');
$('#follow-check').checked=true;$('#follow-check').onchange();$('#confirm-follow').onclick();assert.equal(state.view,'age');assert.equal(state.followConfirmed,true);
state.age=4;state.part='child';state.view='quiz';
for(let i=0;i<5;i++){state.index=i;state.child[i]=1;render();$('#next').onclick();}
assert.equal(state.view,'childResult');assert(root.innerHTML.includes('慢热小蜗牛'));assert.equal(state.parent.length,0);
$('#continue').onclick();assert.equal(state.view,'quiz');assert.equal(state.part,'parent');
for(let i=0;i<5;i++){state.index=i;state.parent[i]=0;render();$('#next').onclick();}
assert.equal(state.view,'parentResult');assert(root.innerHTML.includes('行动派家长'));
$('#continue').onclick();assert.equal(state.view,'combo');assert(root.innerHTML.includes('你已经出发，TA 还在看地图'));
const unique=new Set();
for(let p=0;p<4;p++)for(let c=0;c<4;c++){
 state.parent=Array(5).fill(p);state.child=Array(5).fill(c);const d=comboData();assert(d.certain);unique.add(d.pair[0]);
 for(let scene=0;scene<4;scene++){state.scene=scene;combo();assert(!root.innerHTML.includes('undefined'));assert(root.innerHTML.includes(SCENES[scene].child[c]));assert(root.innerHTML.includes(SCENES[scene].parent[p]));}
}
assert.equal(unique.size,16);
state.parent=[4,4,4,4,4];state.child=[0,0,1,1,4];combo();assert(root.innerHTML.includes('不作单一类型匹配'));
state.note='<img src=x onerror=alert(1)>';combo();assert(root.innerHTML.includes('&lt;img'));assert(!root.innerHTML.includes('<img src=x'));
console.log('PASS: honest follow prompt + confirmation gate, 5+5 staged results, 16 pairings, 64 scene variants, ties, unknowns, escaped notes');
`,ctx);
