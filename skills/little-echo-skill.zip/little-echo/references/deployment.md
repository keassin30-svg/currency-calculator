# 发布与链接

迁移包整理日期：2026-11-27。

原在线地址：
https://little-echo-parent-child.observantmoth6.chatgpt.site

GitHub源码：
https://github.com/keassin30-svg/currency-calculator/blob/main/little-echo/index.html

GitHub Pages地址：
https://keassin30-svg.github.io/currency-calculator/little-echo/

这些是历史项目地址，使用前核验可用性，不保证永久在线。GitHub提交为 4dd471e21d936f18e5bf5cc6765a5cf3a57799bd；不要覆盖仓库根目录原有的汇率计算器。

迁移到其他托管服务：将 assets/index.html 作为站点 index.html 上传，或上传 assets/site/dist 整个目录。所有资源路径是相对路径，支持子目录部署。无需数据库、构建服务或 npm 安装。

直接双击HTML可本地演示，但手机文件预览器未必执行脚本；剪贴板等能力也可能依赖HTTPS。对外分享请使用部署后的HTTPS地址。小红书内能否点击外链取决于平台及账号当前支持的入口，本包不保证。

需要修改现有GitHub版本时，先读取仓库文件及当前SHA，再更新 little-echo/index.html，等待Pages部署完成并验证返回页面。若没有对应权限，交付文件并明确缺少的操作，不虚构部署网址或成功结果。

本包不包含任何平台凭据、会话或托管绑定。目标平台需要自己的文件读取能力；部署需目标账户授权。单个SKILL.md不等于运行中的网站。
