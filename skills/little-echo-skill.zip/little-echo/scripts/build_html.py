from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
src=root/'assets/site/dist'
html=(src/'index.html').read_text(encoding='utf-8')
html=html.replace('<link rel="stylesheet" href="style-v2.css">','<style>\n'+(src/'style-v2.css').read_text(encoding='utf-8')+'\n</style>')
for name in ['data.js','cards.js','app.js']:
    js=(src/name).read_text(encoding='utf-8')
    js=js.replace('</script','<\\/script')
    html=html.replace(f'<script src="{name}"></script>','<script>\n'+js+'\n</script>')
assert not re.search(r'<script[^>]+src=',html)
assert '<!doctype html>' in html.lower()
(root/'assets/index.html').write_text(html,encoding='utf-8')
print('Built assets/index.html')
